import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.swing.JOptionPane;

@SupportedSourceVersion(SourceVersion.RELEASE_11)
 public class Login {
 private String username;
 private String password;
 private String firstName;
 private String lastName;
 
// Regular expression for password complexity

 private static final finalString PASSWORD_REGEX = "^(?=.[A-Z])(?=.[a-z])(?=.[0-9])(?=.[@#$%^&+=])(?=\\S+$).{8,}$";

    public Login {}
 // Getters and setters
 public String getUsername() { return username;}
 public void setUsername(String username) { this.username = username; }
 public String getPassword() { return password; }
 public void setPassword(String password) { this.password = password; }
 public String getFirstName() { return firstName; }
 public void setFirstName(String firstName) { this.firstName = firstName; }
 public String getLastName() { return lastName; }
 public void setLastName(String lastName) { this.lastName = lastName; }

 // Method to validate username
 public boolean isValidUsername() {
 return username != null && username.contains("_") && username.length() <= 5;
 }
 // Method to validate password complexity
 public boolean isValidPassword() {
 if (password == null || password.isEmpty()) return false;
 Pattern pattern = Pattern.compile(PASSWORD_REGEX);
 Matcher matcher = pattern.matcher(password);
 return matcher.matches();
 }
 // Method to register user
 public String registerUser() {
 if (!isValidUsername()) {
 return "Username is not correctly formatted. It should contain an underscore and be at most 5 characters long.";
    }else if (!isValidPassword()) {return "Password is not correctly formatted. It should contain at least 8 characters, including uppercase, lowercase, digit, and special characters.";
 }
 return "User registered successfully!";
 }
 // Method to login user
 public boolean loginUser(String username, String password) {
 return this.username.equals(username) && this.password.equals(password);
 }
 // Method to return login status
 public String returnLoginStatus(boolean status) {
 if (status) {
 return "Welcome " + firstName + " " + lastName + "! It's great to see you again.";
 } else {
 return "Username or password incorrect. Please try again.";
 }
 }
 }
 
    public class Login {
 public static void main(String[] args) {
 RegistrationAndLogin user = new RegistrationAndLogin();
 Scanner scanner = new Scanner(System.in);
 System.out.println("Enter first name:");
 user.setUsername(scanner.nextLine());
 System.out.println("Enter last name:");
 user.setPassword(scanner.nextLine());
 System.out.println("Enter username:");
 user.setFirstname(scanner.nextLine());
 System.out.println("Enter password:");
 user.setLastname(scanner.nextLine());
 System.out.println(user.registerUser());
 System.out.println("Enter username to login:");
 String loginUsername = scanner.nextLine();
 System.out.println("Enter password to login:");
 String loginPassword = scanner.nextLine();
 boolean loginStatus = user.loginUser(loginUsername, loginPassword);
 System.out.println(user.returnLoginStatus(loginStatus));
}


 
 }

    

