/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe.prt2;
import javax.swing.JOptionPane;

/**
 *
 * @author nompumelelo
 */
public class POEPrt2 {
    public class RegistrationAndLogin {
 void setUsername(String nextLine) { 
     throw new UnsupportedOperationException("Not supported yet.");
 } 
 void setPassword(String nextLine) {
     throw new UnsupportedOperationException("Not supported yet.");
 } 
 }
void setLastname(String nextLine) { 
    throw new UnsupportedOperationException("Not supported yet.");
}
 void setFirstname(String nextLine) {throw new UnsupportedOperationException("Not supported yet.");
 
 }
  boolean loginUser(String loginUsername, String loginPassword) {
     throw new UnsupportedOperationException("Not supported yet.");
 }
  boolean returnLoginStatus(boolean loginStatus) {
     throw new UnsupportedOperationException("Not supported yet.");
 }
 }
 
    
    
 
 
 
 
 


