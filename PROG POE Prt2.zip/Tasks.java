
import javax.swing.JOptionPane;
import java.util.Scanner;


public class Tasks {
     public String taskName;
	private int taskNumber;
	public String taskDescription;
	public String developerDetails;
	public int taskDuration;
	public String taskID;
	private String taskStatus;
	private boolean isDone;

	public boolean checkTaskDescription(String taskDescription) {
		if (taskDescription.length() > 50) {
			return false;
		} else {
			return true;
		}
	}

	public String createTaskID(String taskName, int taskNumber, String developerDetails) {
		return taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerDetails.substring(0, 3).toUpperCase();
	}

	public String printTaskDetails() {
		return "Task Status: " + taskStatus + "\nDeveloper Details: " + developerDetails + "\nTask Number: " + taskNumber + "\nTask Name: " + taskName + "\nTask Description: " + taskDescription + "\nTask ID: " + taskID + "\nDuration: " + taskDuration + " hours" + "\nDone: " + (isDone ? "Yes" : "No");
	}

	public int returnTotalHours(int taskDuration) {
		return taskDuration;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public void setDone(boolean isDone) {
		this.isDone = isDone;
	}

	public boolean isDone() {
		return isDone;
	}
}

    

