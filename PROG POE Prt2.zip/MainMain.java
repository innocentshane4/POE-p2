import javax.swing.JOptionPane;
import java.util.Scanner;


public class MainMain {
    public static void main(String[] args) {
                Task.task=new Task();

		// Add tasks
		int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter number of tasks"));
		for (int i = 0; i < numTasks; i++) {
			String taskName = JOptionPane.showInputDialog("Enter task name");
			String taskDescription = JOptionPane.showInputDialog("Enter task description");
			if (!task.checkTaskDescription(taskDescription)) {
				JOptionPane.showMessageDialog(null, "Task description cannot exceed 50 characters");
				continue;
			}
			String developerDetails = JOptionPane.showInputDialog("Enter developer details");
			int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration"));
			task.taskName = taskName;
			task.taskDescription = taskDescription;
			task.developerDetails = developerDetails;
			task.taskDuration = taskDuration;
			task.taskID = task.createTaskID(taskName,taskNumber:i,developerDetails);
			JOptionPane.showMessageDialog(null, task.printTaskDetails());
			String[] options = {"To Do", "Doing", "Done"};
			int status = JOptionPane.showOptionDialog(null, "Select task status", "Task Status", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
			task.setTaskStatus(options[status]);
			if (options[status].equals("Done")) {
				task.setDone(true);
			}
		}

		// Show total hours
		int totalHours = 0;
		for (int i = 0; i < numTasks; i++) {
                    totalHours += task.returnTotalHours(task.taskDuration);
		}
		JOptionPane.showMessageDialog(null, "Total hours: " + totalHours);

		// Show done tasks
		int doneTasks = 0;
		for (int i = 0; i < numTasks; i++) {
			if (task.isDone()) {
				doneTasks++;
			}
		}
		JOptionPane.showMessageDialog(null, "Done tasks: " + doneTasks);
	}

    private static class task {

        private static String taskName;
        private static String taskDescription;
        private static String developerDetails;
        private static int taskDuration;
        private static task taskID;
        private static task createTaskIDtaskName;

        private static boolean isDone() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static Object printTaskDetails() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static void setTaskStatus(String option) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static void setDone(boolean b) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static boolean checkTaskDescription(String taskDescription) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static task createTaskID(String taskName) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public task() {
        }
    }

    private static class Task {

        private static Task task;

        public Task() {
        }
    }
}

    
    

    

